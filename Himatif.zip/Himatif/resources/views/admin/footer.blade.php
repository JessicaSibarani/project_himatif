<!-- Footer -->
<footer class="sticky-footer bg-white" style="border-top: 1px solid #dee2e6; padding: 1rem 0;">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>HIMATIF PA2 Team 1</span>
        </div>
    </div>
</footer>
<!-- End of Footer -->
